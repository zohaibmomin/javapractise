package com.example.hmsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmsappApplicationTests {

	@Test
	void contextLoads() {
	}

}

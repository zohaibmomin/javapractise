package com.example.hmsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HmsappApplication {

	public static void main(String[] args) {
		SpringApplication.run(HmsappApplication.class, args);
	}

}

package com.javapractise.ZohaibSpringBoot.zohaib_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZohaibSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}

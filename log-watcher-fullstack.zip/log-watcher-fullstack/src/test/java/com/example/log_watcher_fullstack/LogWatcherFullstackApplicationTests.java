package com.example.log_watcher_fullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogWatcherFullstackApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.log_watcher_fullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogWatcherFullstackApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogWatcherFullstackApplication.class, args);
	}

}
